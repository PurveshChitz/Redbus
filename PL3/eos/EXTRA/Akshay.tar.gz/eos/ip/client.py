# CLIENT CODE
import socket
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM,socket.IPPROTO_TCP)
host = socket.gethostname()
port = 12347
print "CONNECTING ......"
s.connect((host, port))
me = raw_input(’ROHAN : ’)
s.sendall(me)
server = s.recv(200)
print ’SERVER :’,server
s.close()
