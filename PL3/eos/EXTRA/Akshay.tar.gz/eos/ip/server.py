import socket
s = socket.socket(socket.AF_INET,socket.SOCK_STREAM,socket.IPPROTO_TCP)
host = socket.gethostname()
port = 12348
s.bind((host,port))
s.listen(5)
while (True) :
	new_s, addr=s.accept()
	print ’Got connection from proxy....sending data...’
	user = new_s.recv(200)
	print ’User : ’,user
	new_s.send("CONNECTION WAS SUCCESSFULL....")
s.close()
new_s.close()
